token = "Paste your bot's token here"
